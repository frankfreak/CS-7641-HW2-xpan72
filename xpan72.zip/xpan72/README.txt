Author        : Xiaoyu Pan
Created       : Mar, 3 2019
Last Modified : Mar, 3 2019
Affiliation   : Georgia Institue of Technology

Description.  :
Dataset citation: http://archive.ics.uci.edu/ml/datasets/Spambase
ABAGAIL Open Library:https://github.com/pushkar/ABAGAIL

All code and dataset for this homework could be found at https://github.com/frankfreak/CS-7641-HW.
Download (or clone) ABAGAIL folder.

To run the code:
>cd ABAGAIL
>ant
Part 1:
RHC:
	>java -cp ABAGAIL.jar project2.SpambaseTest src/project2/datasets/spambase.arff rhc 5 4000
				args[0] dataset file
				args[1] randomized optimization algorithm to use
			   	args[2] hidden layers
			    args[3] iterations
Simulated Annealing:
	>java -cp ABAGAIL.jar project2.SpambaseTest src/project2/datasets/spambase.arff sa 6 4000 1e6 0.5
				args[4] temperature
				args[5] ooling factor
Genetic Algorithm:
	>java -cp ABAGAIL.jar project2.SpambaseTest src/project2/datasets/spambase.arff ga 6 4000 200 25 100
				args[4] population size
				args[5] mate per iteration
				args[6] mutations per iteration


Part 2:
TSP:
	>java -cp ABAGAIL.jar opt.test.TravelingSalesmanTest
Flip Flop
	>java -cp ABAGAIL.jar opt.test.FlipFlopTest 80 200
Knapsack Problem
	>java -cp ABAGAIL.jar opt.test.KnapsackTest
	
CSV files are generated for each result, you can find them under ABAGAIL folder.